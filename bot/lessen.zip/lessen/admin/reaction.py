import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from admin.menu import admin_menu
from config import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


# 'rol', 'action', 'id', 'page'

# 😀😃😄😁😆


async def admin_reaction_main(message: types.CallbackQuery, vote_cb: aiogram.utils.callback_data.CallbackData):
    markup = InlineKeyboardMarkup().add(
        InlineKeyboardButton(text="Darsliklarni reaksiyalari",
                             callback_data=vote_cb.new(rol='admin', action="reaction", id="option", page='')),
        InlineKeyboardButton(text="Darsimiz xaqida",
                             callback_data=vote_cb.new(rol='admin', action="reaction", id="opinion", page=''))
    )
    await bot.send_message(message.from_user.id,
                           "Darsliklarni reaksiyalarini ko'rmoqchimisiz yoki o'quvchilarni fikrini bilmoqchimisiz",
                           reply_markup=markup)


async def admin_reaction_option(message: types.CallbackQuery, main_conn: sqlite3.Connection):
    lessens = main_conn.execute("select id from lessen_table;").fetchall()
    option = main_conn.execute("select * from option limit 1;").fetchall()
    if option:
        awa = ""
        for i in lessens:
            option = main_conn.execute("select name from option where number = (?);", (i[0],)).fetchall()
            if option:
                awa += str(i[0]) + " - dars\n"
            for o in option:
                if o[0] == 1:
                    awa += "👎 "
                elif o[0] == 2:
                    awa += "👍 "
                elif o[0] == 3:
                    awa += "🔥 "
                elif o[0] == 4:
                    awa += "🚀 "
            awa += "\n\n"
        await bot.send_message(message.from_user.id, awa)
    else:
        await bot.send_message(message.from_user.id, "Reaksiyalar hozircha yo'q")


async def admin_reaction_opinion(message: types.CallbackQuery, main_conn: sqlite3.Connection, vote_cb: aiogram.utils.callback_data.CallbackData):
    opinion = main_conn.execute("select * from opinion limit 1;").fetchall()
    if opinion:
        opinion = main_conn.execute("select text from opinion limit 1;").fetchall()
        awa = ""
        son = 1
        for i in opinion:
            awa += str(son) + ". " + i[0]
            awa += "\n\n"
        await bot.send_message(message.from_user.id, awa)
    else:
        await bot.send_message(message.from_user.id, "Fikrlar hozircha yo'q")
        await admin_menu(message, vote_cb, main_conn)
