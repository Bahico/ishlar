import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from config import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


# 'rol', 'action', 'id', 'page'


async def admin_menu(message: types.Message or types.CallbackQuery, vote_cb: aiogram.utils.callback_data.CallbackData, main_conn: sqlite3.Connection):
    markup = InlineKeyboardMarkup(row_width=1).row(
        InlineKeyboardButton(text="📚Darslik qo'shish",
                             callback_data=vote_cb.new(rol='admin', action="lessen", id="add", page='')),
        InlineKeyboardButton(text="📚Darslik o'zgartirish",
                             callback_data=vote_cb.new(rol='admin', action="lessen", id="edit", page='')),
    )
    markup.row(
        InlineKeyboardButton(text="🧑‍🎓O'quvchilar",
                             callback_data=vote_cb.new(rol='admin', action="student", id="information", page=10)),
        InlineKeyboardButton(text="Reaksiyalar", callback_data=vote_cb.new(rol='admin', action="reaction", id="main", page='')),
        InlineKeyboardButton(text="Bilet",
                             callback_data=vote_cb.new(rol='admin', action="ticket", id="information", page=''))
    )
    markup.add(
        InlineKeyboardButton(text="Barcha uchun",
                             callback_data=vote_cb.new(rol='admin', action="message", id="information", page=''))
    )
    markup.row(
        InlineKeyboardButton(text="📚O'zimiz xaqimizdagi video", callback_data=vote_cb.new(rol='admin', action="information", id="lesson add", page=''))
    )
    await bot.send_message(message.from_user.id, "Admin menu", reply_markup=markup)
    main_conn.execute("update all_user set text = null where id = (?);", (message.from_user.id,))
