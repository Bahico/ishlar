import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from admin.menu import admin_menu
from config import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


async def admin_lessen_del_day(message: types.CallbackQuery, main_conn: sqlite3.Connection,
                               vote_cb: aiogram.utils.callback_data.CallbackData):
    lessens = main_conn.execute("select id from lessen_table;").fetchall()
    markup = InlineKeyboardMarkup(row_width=2)
    for lessen in lessens:
        if lessen[0] != 0:
            markup.insert(InlineKeyboardButton(text=str(lessen[0]) + " - dars",
                                               callback_data=vote_cb.new(rol='admin', action="edit", id="edit",
                                                                         page=lessen[0])))
    await bot.send_message(message.from_user.id, "Nechinchi videoni o'zgartirmoqchisiz", reply_markup=markup)


async def admin_lessen_edit_start(message: types.CallbackQuery, main_conn: sqlite3.Connection,
                                  vote_cb: aiogram.utils.callback_data.CallbackData, callback_query: dict):
    markup = InlineKeyboardMarkup().row(
        InlineKeyboardButton(text="⬅️ORTGA", callback_data=vote_cb.new(rol='admin', action="back", id="back", page=''))
    )
    main_conn.execute("update all_user set text = 'edit lessen video', save = (?) where id = (?);",
                      (callback_query["page"], message.from_user.id,))
    await bot.send_message(message.from_user.id, str(callback_query['page']) + "- darslikni videosini yuboring",
                           reply_markup=markup)


async def admin_lessen_edit_title(message: types.Message, main_conn: sqlite3.Connection,
                                  vote_cb: aiogram.utils.callback_data.CallbackData):
    markup = InlineKeyboardMarkup().row(
        InlineKeyboardButton(text="⬅️ORTGA", callback_data=vote_cb.new(rol='admin', action="back", id="back", page=''))
    )
    admin = main_conn.execute("select save from all_user where id = (?);", (message.from_user.id,)).fetchall()[0]
    main_conn.execute("""update lessen_table set text = (?) where id = (?);""", (message.text,admin[0],))
    main_conn.execute("update all_user set text = null, save = null where id = (?);", (message.from_user.id,))
    await bot.send_message(message.from_user.id, "✅Qabul qilindi", reply_markup=markup)
    await admin_menu(message, vote_cb, main_conn)


# async def admin_lessen_edit_test(message: types.Message, main_conn: sqlite3.Connection,
#                                  vote_cb: aiogram.utils.callback_data.CallbackData, user: list):
#     markup = InlineKeyboardMarkup().row(
#         InlineKeyboardButton(text="⬅️ORTGA", callback_data=vote_cb.new(rol='admin', action="back", id="back", page=''))
#     )
#     main_conn.execute(f"update lessen_table set video = '{user[2]}', title = '{message.text}' where id = (?);", (user[3],))
#     main_conn.execute("update all_user set save = (?), text = 'edit lessen answer', test = 1 where id = (?);",
#                       (str(user[3]), message.from_user.id,))
#     await bot.send_message(message.from_user.id, "Test javobini yuboring", reply_markup=markup)
#
#
# async def admin_lessen_edit_answer(message: types.Message, main_conn: sqlite3.Connection, user: list):
#     try:
#         int(message.text)
#         main_conn.execute("update lessen_table set answer = (?) where id = (?);", (int(message.text), int(user[2])))
#         main_conn.execute("update all_user set text = 'edit lessen option', test = 1 where id = (?);",
#                           (message.from_user.id,))
#         await bot.send_message(message.from_user.id, "1 - variantni yuboring")
#     except:
#         await bot.send_message(message.from_user.id, "Iltimos son yuboring")
#
#
# async def admin_lessen_edit_option(message: types.Message, main_conn: sqlite3.Connection,
#                                    vote_cb: aiogram.utils.callback_data.CallbackData, user: list):
#     if user[3] >= 4:
#         main_conn.execute(f"insert into option(number,id,name) where (?,?,'{message.text}');", (int(user[1]), user[3]))
#         if user[3] + 1 <= 4:
#             await bot.send_message(message.from_user.id, "4 ta variant qo'shib bolindi")
#             await admin_menu(message, vote_cb)
#             main_conn.execute("update all_user set save = null, text = null, test = null where id = (?);",
#                               (message.from_user.id,))
#         else:
#             await bot.send_message(message.from_user.id, str(user[3] + 1) + "-variantni kiriting")
#             main_conn.execute("update all_user set test = (?) where id = (?);",
#                               (user[3] + 1, message.from_user.id,))
#     else:
#         main_conn.execute("update all_user set save = null, text = null, test = null where id = (?);",
#                           (message.from_user.id,))
#         await bot.send_message(message.from_user.id, "4 ta variantan ko'p qo'shish mumkin emas")
