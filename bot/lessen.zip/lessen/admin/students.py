import sqlite3
import xlsxwriter

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from config import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


# 'rol', 'action', 'id', 'page'


async def admin_student_main(message: types.CallbackQuery, vote_cb: aiogram.utils.callback_data.CallbackData):
    markup = InlineKeyboardMarkup().row(
        InlineKeyboardButton(text="Chiqib ketganlar",
                             callback_data=vote_cb.new(rol='admin', action="student", id="false",
                                                       page=10)),
        InlineKeyboardButton(text="Hozir borlar",
                             callback_data=vote_cb.new(rol='admin', action="student", id="true",
                                                       page=10))
    )
    markup.add(
        InlineKeyboardButton(text="Excel file",
                             callback_data=vote_cb.new(rol='admin', action="student", id="excel",
                                                       page=""))
    )
    await bot.send_message(message.from_user.id, "Hozir botda borlarni ko'rmoqchimsiz yoki chiqib ketganlarni",
                           reply_markup=markup)


async def admin_students_excel(message: types.CallbackQuery, main_conn: sqlite3.Connection):
    workbook = xlsxwriter.Workbook('hello.xlsx')
    worksheet = workbook.add_worksheet()
    students = main_conn.execute("select * from students;").fetchall()
    row = 0
    col = 0
    for id, name, age, phone_number, reason, work in students:
        if id:
            worksheet.write(row, col, id)
        else:
            worksheet.write(row, col, "Chiqib ketgan")
        worksheet.write(row, col + 1, name)
        if age:
            worksheet.write(row, col + 2, str(age))
            if phone_number:
                worksheet.write(row, col + 3, str(phone_number))
                if reason:
                    worksheet.write(row, col + 4, reason)
                    if work:
                        worksheet.write(row, col + 5, work)
        row += 1
    workbook.close()
    await bot.send_document(message.from_user.id, document=open("hello.xlsx", "rb"), thumb="document")


async def admin_students_false(message: types.CallbackQuery, main_conn: sqlite3.Connection,
                               vote_cb: aiogram.utils.callback_data.CallbackData, callback_query: dict):
    students = main_conn.execute("select id, name from students limit (?);", (callback_query["page"],)).fetchall()
    markup = InlineKeyboardMarkup(row_width=2)
    if students:
        student = students[int(callback_query["page"]) - 10:]
        if not student:
            student = students[:10]
    else:
        student = main_conn.execute("select id, name from students limit 10;").fetchall()
    for i in student:
        if i[0] is None:
            markup.insert(InlineKeyboardButton(text=i[1],
                                               callback_data=vote_cb.new(rol='admin', action="student", id="false_",
                                                                         page=i[1])))
    markup.add(InlineKeyboardButton(text="➡️",
                                    callback_data=vote_cb.new(rol='admin', action="student", id="false",
                                                              page=int(callback_query["page"]) + 10)))
    await bot.send_message(message.from_user.id, "Qaysi o'quvchini malumotlarini ko'rmoqchisiz?", reply_markup=markup)


async def admin_students_true(message: types.CallbackQuery, main_conn: sqlite3.Connection,
                              vote_cb: aiogram.utils.callback_data.CallbackData, callback_query: dict):
    students = main_conn.execute("select id, name from students limit (?);", (callback_query["page"],)).fetchall()
    markup = InlineKeyboardMarkup(row_width=2)
    if students:
        student = students[int(callback_query["page"]) - 10:]
        if not student:
            student = students[:10]
            markup.add(InlineKeyboardButton(text="➡️",
                                            callback_data=vote_cb.new(rol='admin', action="student", id="true",
                                                                      page=10)))
        else:
            markup.add(InlineKeyboardButton(text="➡️",
                                            callback_data=vote_cb.new(rol='admin', action="student", id="true",
                                                                      page=int(callback_query["page"]) + 10)))
    else:
        student = main_conn.execute("select id, name from students limit 10;").fetchall()
    for i in student:
        if i[0] is not None:
            markup.insert(InlineKeyboardButton(text=i[1],
                                               callback_data=vote_cb.new(rol='admin', action="student", id="true_",
                                                                         page=str(i[0]))))
    await bot.send_message(message.from_user.id, "Qaysi o'quvchini malumotlarini ko'rmoqchisiz?", reply_markup=markup)


async def admin_student(message: types.CallbackQuery, main_conn: sqlite3.Connection, callback_query: dict):
    if callback_query["id"] == "true_":
        student = \
            main_conn.execute("select * from students where id = (?);", (int(callback_query["page"]),)).fetchall()[0]
        if student[5] is not None:
            awa = "To'liq ismi: " + student[1] + "\nYoshi: " + str(student[2]) + "\nTelefon raqami: +" + str(
                student[3]) + "\nSabab: " + student[4] + "\nIsh yoki o'qish joyi: " + student[5]
            await bot.send_message(message.from_user.id, awa)
        else:
            await bot.send_message(message.from_user.id, "Hali to'liq ro'yxatdan o'tgani yo'q")
    else:
        student = \
            main_conn.execute("""select * from students where name = (?);""", (callback_query["page"],)).fetchall()[0]
        if student[5] is not None:
            awa = "To'liq ismi: " + student[1] + "\nYoshi: " + str(student[2]) + "\nTelefon raqami: +" + str(
                student[3]) + "\nSabab: " + student[4] + "\nIsh yoki o'qish joyi: " + student[5]
            await bot.send_message(message.from_user.id, awa)
        else:
            await bot.send_message(message.from_user.id, "Hali to'liq ro'yxatdan o'tgani yo'q")
