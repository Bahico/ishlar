import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from config import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


async def admin_lessen_add_start(message: types.CallbackQuery, main_conn: sqlite3.Connection,
                                 vote_cb: aiogram.utils.callback_data.CallbackData):
    markup = InlineKeyboardMarkup().row(
        InlineKeyboardButton(text="⬅️ORTGA", callback_data=vote_cb.new(rol='admin', action="back", id="back", page=''))
    )
    son = main_conn.execute("select id from lessen_table where not id = 0;").fetchall()
    main_conn.execute("update all_user set text = 'add lessen video' where id = (?);", (message.from_user.id,))
    if son:
        await bot.send_message(message.from_user.id, str(son[-1][0] + 1) + "-darslikni videosini yuboring",
                               reply_markup=markup)
    else:
        await bot.send_message(message.from_user.id, "1-darslikni videosi", reply_markup=markup)


async def admin_lessen_add_video(message: types.Message, main_conn: sqlite3.Connection):
    admin = main_conn.execute("select text, save from all_user where id = (?);", (message.from_user.id,)).fetchall()
    video = main_conn.execute("select * from lessen_table where id = 0;").fetchall()
    if admin:
        admin = admin[0]
        if admin[0] == "add lessen video":
            main_conn.execute(f"insert into lessen_table(video) values (?);", (message.video.file_id,))
            lessen = \
                main_conn.execute("select id from lessen_table where video = (?);",
                                  (message.video.file_id,)).fetchall()[-1][0]
            main_conn.execute("update all_user set text = 'add lessen title', save = (?) where id = (?);",
                              (lessen, message.from_user.id,))
            await bot.send_message(message.from_user.id, "Dars Mavzusini kiriting")
        elif admin[0] == "information video add":
            if video:
                main_conn.execute(f"update lessen_table set video = '{message.video.file_id}' where id = 0;")
                await bot.send_message(message.from_user.id, "Qabul qilindi✅")
            else:
                main_conn.execute(f"insert into lessen_table(id,video) values (0,'{message.video.file_id}')")
                await bot.send_message(message.from_user.id, "Qabul qilindi✅")
        elif admin[0] == "edit lessen video":
            main_conn.execute(f"update lessen_table set video = (?) where id = (?);", (message.video.file_id, admin[1]))
            main_conn.execute("update all_user set text = 'edit lessen title' where id = (?);",
                              (message.from_user.id,))
            await bot.send_message(message.from_user.id, "Dars Mavzusini kiriting")


async def admin_lessen_add_title(message: types.Message, main_conn: sqlite3.Connection,
                                 vote_cb: aiogram.utils.callback_data.CallbackData, user: list):
    markup = InlineKeyboardMarkup().row(
        InlineKeyboardButton(text="⬅️ORTGA",
                             callback_data=vote_cb.new(rol='admin', action="back", id="back", page='')),
        InlineKeyboardButton(text="✅HA",
                             callback_data=vote_cb.new(rol='admin', action="lessen", id="add", page=''))
    )
    main_conn.execute("""update lessen_table set text = (?) where id = (?);""", (message.text, user[2],))
    main_conn.execute("update all_user set save = null, text = null where id = (?);", (message.from_user.id,))
    await bot.send_message(message.from_user.id, "Yana darslik qo'shasizmi?", reply_markup=markup)


async def admin_information_add(message: types.CallbackQuery, main_conn: sqlite3.Connection):
    main_conn.execute("update all_user set text = 'information video add' where id = (?);", (message.from_user.id,))
    await bot.send_message(message.from_user.id, "O'zimiz haqimizdagi videoni tashlang")

# async def admin_lessen_add_test(message: types.Message, main_conn: sqlite3.Connection,
#                                 vote_cb: aiogram.utils.callback_data.CallbackData, user: list):
#     markup = InlineKeyboardMarkup().row(
#         InlineKeyboardButton(text="⬅️ORTGA", callback_data=vote_cb.new(rol='admin', action="back", id="back", page=''))
#     )
#     main_conn.execute(f"insert into lessen_table(video,title) values ('{user[2]}','{message.text}')")
#     save = \
#         main_conn.execute(
#             f"select id from lessen_table where video = '{user[2]}' and title = '{message.text}';").fetchall()[
#             0][0]
#     main_conn.execute("update all_user set save = (?), text = 'add lessen answer', test = 1 where id = (?);",
#                       (str(save), message.from_user.id,))
#     await bot.send_message(message.from_user.id, "Test javobini yuboring", reply_markup=markup)
#
#
# async def admin_lessen_add_answer(message: types.Message, main_conn: sqlite3.Connection, user: list):
#     try:
#         int(message.text)
#         main_conn.execute("update lessen_table set answer = (?) where id = (?);", (int(message.text), int(user[2])))
#         main_conn.execute("update all_user set text = 'add lessen option', test = 1 where id = (?);",
#                           (message.from_user.id,))
#         await bot.send_message(message.from_user.id, "1 - variantni yuboring")
#     except:
#         await bot.send_message(message.from_user.id, "Iltimos son yuboring")
#
#
# async def admin_lessen_add_option(message: types.Message, main_conn: sqlite3.Connection,
#                                   vote_cb: aiogram.utils.callback_data.CallbackData, user: list):
#     if user[3] >= 4:
#         main_conn.execute(f"insert into option(number,id,name) where (?,?,'{message.text}');", (int(user[1]), user[3]))
#         if user[3] + 1 <= 4:
#             await bot.send_message(message.from_user.id, "4 ta variant qo'shib bolindi")
#             await admin_menu(message, vote_cb)
#             main_conn.execute("update all_user set save = null, text = null, test = null where id = (?);",
#                               (message.from_user.id,))
#         else:
#             await bot.send_message(message.from_user.id, str(user[3] + 1) + "-variantni kiriting")
#             main_conn.execute("update all_user set test = (?) where id = (?);",
#                               (user[3] + 1, message.from_user.id,))
#     else:
#         main_conn.execute("update all_user set save = null, text = null, test = null where id = (?);",
#                           (message.from_user.id,))
#         await bot.send_message(message.from_user.id, "4 ta variantan ko'p qo'shish mumkin emas")
