import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher

from admin.menu import admin_menu
from config import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


# 'rol', 'action', 'id', 'page'


async def admin_all_message(message: types.CallbackQuery, main_conn: sqlite3.Connection):
    main_conn.execute("update all_user set text = 'all user message' where id = (?);", (message.from_user.id,))
    await bot.send_message(message.from_user.id, "Text yuboring")


async def admin_all_message_send(message: types.Message, main_conn: sqlite3.Connection,
                                 vote_cb: aiogram.utils.callback_data.CallbackData):
    students = main_conn.execute("select id from students;").fetchall()
    for i in students:
        await bot.send_message(i[0], message.text)
    await bot.send_message(message.from_user.id, "Mufaqiyatli jo'natildi✅")
    await admin_menu(message, vote_cb, main_conn)
