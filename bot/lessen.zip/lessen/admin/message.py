import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher

# from admin.lessen_add import admin_lessen_add_test, admin_lessen_add_answer, admin_lessen_add_option
from admin.all_message import admin_all_message_send
from admin.lessen_add import admin_lessen_add_title
from admin.lessen_del import admin_lessen_edit_title
from admin.start import admin_password
from config import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


async def admin_message(message: types.Message, main_conn: sqlite3.Connection, vote_cb: aiogram.utils.callback_data.CallbackData, user: list):
    text = user[1]
    if text == "password":
        await admin_password(message, main_conn, vote_cb, user)
    elif text == "add lessen title":
        await admin_lessen_add_title(message, main_conn, vote_cb, user)
    elif text == "edit lessen title":
        await admin_lessen_edit_title(message, main_conn, vote_cb)
    elif text == "all user message":
        await admin_all_message_send(message, main_conn, vote_cb)
    #     await admin_lessen_add_test(message, main_conn, vote_cb, user)
    # elif text == "add lessen answer":
    #     await admin_lessen_add_answer(message, main_conn, user)
    # elif text == "add lessen option":
    #     await admin_lessen_add_option(message, main_conn, vote_cb, user)
    # elif text == "edit lessen video":
    #     await admin_lessen_edit_title(message, main_conn, vote_cb)
    # elif text == "edit lessen title":
    #     await admin_lessen_edit_test(message, main_conn, vote_cb, user)
    # elif text == "edit lessen answer":
    #     await admin_lessen_edit_answer(message, main_conn, user)
    # elif text == "edit lessen option":
    #     await admin_lessen_edit_option(message, main_conn, vote_cb, user)
