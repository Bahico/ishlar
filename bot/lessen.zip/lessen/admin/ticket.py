import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher

from admin.menu import admin_menu
from config import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


# 'rol', 'action', 'id', 'page'


async def admin_ticket(message: types.CallbackQuery, main_conn: sqlite3.Connection):
    main_conn.execute("update all_user set text = 'ticket' where id = (?);", (message.from_user.id,))
    await bot.send_message(message.from_user.id, "Bilet rasmini yuboring")


async def admin_ticket_photo(message: types.Message, main_conn: sqlite3.Connection,
                             vote_cb: aiogram.utils.callback_data.CallbackData):
    admin = main_conn.execute("select name, text from all_user where id = (?);", (message.from_user.id,)).fetchall()
    if admin and admin[0][0] == "admin" and admin[0][1]:
        main_conn.execute("delete from photo;")
        main_conn.execute("insert into photo(photo) values (?);", (message.photo[0].file_id,))
        await bot.send_message(message.from_user.id, "Qabul qilindi")
        await admin_menu(message, vote_cb, main_conn)
    else:
        await message.delete()
