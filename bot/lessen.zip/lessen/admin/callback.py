import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher

from admin.all_message import admin_all_message
from admin.lessen_add import admin_lessen_add_start, admin_information_add
from admin.lessen_del import admin_lessen_edit_start, admin_lessen_del_day
from admin.menu import admin_menu
from admin.reaction import admin_reaction_main, admin_reaction_opinion, admin_reaction_option
from admin.students import admin_students_true, admin_student, admin_student_main, admin_students_false, \
    admin_students_excel
from admin.ticket import admin_ticket
from config import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


async def admin_callback(message: types.CallbackQuery, main_conn: sqlite3.Connection,
                         vote_cb: aiogram.utils.callback_data.CallbackData, callback_query: dict):
    if callback_query["action"] == "lessen":
        await bot.delete_message(message.from_user.id, message.message.message_id)
        if callback_query["id"] == "add":
            await admin_lessen_add_start(message, main_conn, vote_cb)
        elif callback_query["id"] == "edit":
            await admin_lessen_del_day(message, main_conn, vote_cb)
    elif callback_query["action"] == "student":
        await bot.delete_message(message.from_user.id, message.message.message_id)
        if callback_query["id"] == "information":
            await admin_student_main(message, vote_cb)
        elif callback_query["id"] == "true_":
            await admin_student(message, main_conn, callback_query)
        elif callback_query["id"] == "false_":
            await admin_student(message, main_conn, callback_query)
        elif callback_query["id"] == "false":
            await admin_students_false(message, main_conn, vote_cb, callback_query)
        elif callback_query["id"] == "true":
            await admin_students_true(message, main_conn, vote_cb, callback_query)
        elif callback_query["id"] == "excel":
            await admin_students_excel(message, main_conn)
    elif callback_query["action"] == 'edit':
        await admin_lessen_edit_start(message, main_conn, vote_cb, callback_query)
    elif callback_query["action"] == "message":
        if callback_query["id"] == "information":
            await admin_all_message(message, main_conn)
    elif callback_query["action"] == "information":
        await bot.delete_message(message.from_user.id, message.message.message_id)
        if callback_query["id"] == "lesson add":
            await admin_information_add(message, main_conn)

    elif callback_query["action"] == "ticket":
        await bot.delete_message(message.from_user.id, message.message.message_id)
        await admin_ticket(message, main_conn)

    elif callback_query["action"] == "ticket":
        await bot.delete_message(message.from_user.id, message.message.message_id)
        await admin_ticket(message, main_conn)

    elif callback_query["action"] == "back":
        main_conn.execute("update all_user set text = null, save = null, test = null where id = (?);",
                          (message.from_user.id,))
        await bot.delete_message(message.from_user.id, message.message.message_id)
        await admin_menu(message, vote_cb, main_conn)

    elif callback_query["action"] == "reaction":
        await bot.delete_message(message.from_user.id, message.message.message_id)
        if callback_query["id"] == "main":
            await admin_reaction_main(message, vote_cb)
        elif callback_query["id"] == "opinion":
            await admin_reaction_opinion(message, main_conn, vote_cb)
        elif callback_query["id"] == "option":
            await admin_reaction_option(message, main_conn)
