import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher

from admin.menu import admin_menu
from config import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


async def admin_start(message: types.Message, main_conn: sqlite3.Connection,
                      vote_cb: aiogram.utils.callback_data.CallbackData):
    admin = main_conn.execute('select text, name from all_user where id = (?);', (message.from_user.id,)).fetchall()
    if admin and admin[0][0] != 'password' and admin[0][1] == "admin":
        await admin_menu(message, vote_cb, main_conn)
    else:
        main_conn.execute("delete from all_user where id = (?);", (message.from_user.id,))
        main_conn.execute("insert into all_user(name,id,text,test) values ('admin',?,'password',0);",
                          (message.from_user.id,))
        await bot.send_message(message.from_user.id, "Password: ")


async def admin_password(message: types.Message, main_conn: sqlite3.Connection,
                         vote_cb: aiogram.utils.callback_data.CallbackData, user: list):
    code = main_conn.execute("select * from code;").fetchall()[0][0]
    if code == message.text:
        main_conn.execute("update all_user set text = null, save = '0', test = 0 where id = (?);",
                          (message.from_user.id,))
        await bot.send_message(message.from_user.id, "Qabul qilindi✅")
        await admin_menu(message, vote_cb, main_conn)
    else:
        if user[3] + 1 > 3:
            main_conn.execute("delete from all_user where id = (?);", (message.from_user.id,))
            await bot.send_message(message.from_user.id, "Noto'g'ri❌")
        else:
            main_conn.execute("update all_user set test = (?) where id = (?);",
                              (user[3] + 1, message.from_user.id,))
            son = 3 - user[3]
            await bot.send_message(message.from_user.id, "Noto'g'ri❌\n" + str(son) + " ta imkoniyatiz qoldi")
