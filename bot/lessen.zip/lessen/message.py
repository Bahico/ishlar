import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher

from admin.message import admin_message
from config import TOKEN
from user.message import user_message

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


async def main_message(message: types.Message, main_conn: sqlite3.Connection, vote_cb: aiogram.utils.callback_data.CallbackData):
    user = main_conn.execute("select name, text, save, test from all_user where id = (?);", (message.from_user.id,)).fetchall()
    if user and user[0][0] == "admin":
        await admin_message(message, main_conn, vote_cb, user[0])
    elif user and user[0][0] == "user":
        await user_message(message, main_conn, vote_cb, user[0])


