import logging
import sqlite3

from aiogram.dispatcher import Dispatcher
from aiogram import Bot, types
from aiogram.utils import executor
from aiogram.utils.callback_data import CallbackData

from admin.callback import admin_callback
from admin.lessen_add import admin_lessen_add_video
from admin.start import admin_start
from admin.ticket import admin_ticket_photo
from config import TOKEN
from message import main_message
from user.callback import user_callback
from user.start import user_start, user_contact
import xlsxwriter

vote_cb = CallbackData('vote', 'rol', 'action', 'id', 'page')

logging.basicConfig(level=logging.INFO)

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

main_conn = sqlite3.connect('dp.db')


@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    await user_start(message, main_conn, vote_cb)
    await message.delete()
    main_conn.commit()


@dp.message_handler(commands=['admin'])
async def admin(message: types.Message):
    await admin_start(message, main_conn, vote_cb)
    await message.delete()
    main_conn.commit()


@dp.message_handler(commands=['logout'])
async def logout(message: types.Message):
    main_conn.execute("delete from all_user where id = (?);", (message.from_user.id,))
    main_conn.execute("update students set id = null where id = (?);", (message.from_user.id,))
    await bot.send_message(message.from_user.id, "Logout")
    main_conn.commit()


@dp.callback_query_handler(vote_cb.filter(rol="admin"))
async def user(message: types.CallbackQuery, callback_data: dict):
    await admin_callback(message, main_conn, vote_cb, callback_data)
    main_conn.commit()


@dp.callback_query_handler(vote_cb.filter(rol="user"))
async def user(message: types.CallbackQuery, callback_data: dict):
    await user_callback(message, main_conn, vote_cb, callback_data)
    main_conn.commit()


@dp.message_handler(content_types=['video'])
async def video(message: types.Message):
    await admin_lessen_add_video(message, main_conn)


@dp.message_handler(content_types=['contact'])
async def video(message: types.Message):
    await user_contact(message, main_conn)


@dp.message_handler(content_types=['photo'])
async def video(message: types.Message):
    await admin_ticket_photo(message, main_conn, vote_cb)


@dp.message_handler()
async def message_(message: types.Message):
    await main_message(message, main_conn, vote_cb)
    main_conn.commit()


if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)
