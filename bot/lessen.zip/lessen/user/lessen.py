import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from config import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


async def user_lessen(message: types.CallbackQuery or types.Message, main_conn: sqlite3.Connection,
                      vote_cb: aiogram.utils.callback_data.CallbackData, callback_query: dict):
    id = int(callback_query["page"])
    video = main_conn.execute("select video, text from lessen_table where id = (?);", (id,)).fetchall()
    video1 = main_conn.execute("select video from lessen_table where id = (?);", (id + 1,)).fetchall()
    if video:
        markup = InlineKeyboardMarkup().row(
            InlineKeyboardButton(text="👎",
                                 callback_data=vote_cb.new(rol='user', action="reaction", id=str(id), page='1')),
            InlineKeyboardButton(text="👍",
                                 callback_data=vote_cb.new(rol='user', action="reaction", id=str(id), page='2')),
            InlineKeyboardButton(text="🔥",
                                 callback_data=vote_cb.new(rol='user', action="reaction", id=str(id), page='3')),
            InlineKeyboardButton(text="🚀",
                                 callback_data=vote_cb.new(rol='user', action="reaction", id=str(id), page='4'))
        )
        if video1:
            markup.add(
                InlineKeyboardButton(text=str(id + 1) + " - darsni ko'rish",
                                     callback_data=vote_cb.new(rol='user', action="lessen", id="start",
                                                               page=str(id + 1)))
            )
        else:
            markup.add(
                InlineKeyboardButton(text="FINISH",
                                     callback_data=vote_cb.new(rol='user', action="lessen", id="start",
                                                               page=str(id + 1)))
            )
        await bot.send_video(message.from_user.id, video[0][0], caption=video[0][1] + "\n\nReaksiya qoldiring",
                             reply_markup=markup)
    else:
        markup = InlineKeyboardMarkup().row(
            InlineKeyboardButton(text="Unchalik emas",
                                 callback_data=vote_cb.new(rol='user', action="finish", id="reaction", page='1')),
            InlineKeyboardButton(text="albatta yoqdi ",
                                 callback_data=vote_cb.new(rol='user', action="finish", id="reaction", page='2')),
        )
        markup.add(
            InlineKeyboardButton(text="albatta ko'p bilmagan savvolarimga javob oldim ",
                                 callback_data=vote_cb.new(rol='user', action="finish", id="reaction", page='3')),
            InlineKeyboardButton(text="o'zim bilmagan savollarimga javob oldim",
                                 callback_data=vote_cb.new(rol='user', action="finish", id="reaction", page='I'))
        )
        await bot.send_message(message.from_user.id, "Sizga SMM bo'yicha BEPUL darslarimiz yoqdimi?",
                               reply_markup=markup)


async def user_smile(message: types.CallbackQuery, main_conn: sqlite3.Connection,
                     vote_cb: aiogram.utils.callback_data.CallbackData, callback_query: dict):
    main_conn.execute("insert into option(number,name) values (?,?);", (callback_query["id"], callback_query["page"]))
    await bot.send_message(message.from_user.id, "Fikringiz uchun rahmat😊")
    callback_query["page"] = int(callback_query["id"]) + 1
    await user_lessen(message, main_conn, vote_cb, callback_query)


async def user_mes(message: types.CallbackQuery, main_conn: sqlite3.Connection):
    main_conn.execute("update all_user set text = 'main fikr' where id = (?);", (message.from_user.id,))
    await bot.send_message(message.from_user.id, "O'z fikringizni yuboring")


async def user_opinion(message: types.Message, main_conn: sqlite3.Connection):
    main_conn.execute("""insert into opinion(id,text) values (?,?)""", (message.from_user.id, message.text))
    await bot.send_message(message.from_user.id,
                           "Bildirgan fikringiz uchun raxmat,\n Sizga master klassda ishtirok etish uchun bilet taqdim etamiz.")
    main_conn.execute("update all_user set text = null where id = (?);", (message.from_user.id,))


async def user_finish(message: types.CallbackQuery, main_conn: sqlite3.Connection, callback_query: dict):
    main_conn.execute("update all_user set text = null where id = (?);", (message.from_user.id,))
    main_conn.execute("insert into option(number,name) values (0,?);", (callback_query["page"],))
    # user = main_conn.execute("select name from students where id = (?);", (message.from_user.id,)).fetchall()[0][0]
    await bot.send_message(message.from_user.id,
                           "Bildirgan fikringiz uchun raxmat,\n\n Sizga master klassda ishtirok etish uchun bilet taqdim etamiz.")
