import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup, \
    ReplyKeyboardRemove

from admin.menu import admin_menu
from config import TOKEN
from user.lessen import user_lessen

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


async def user_start(message: types.Message, main_conn: sqlite3.Connection,
                     vote_cb: aiogram.utils.callback_data.CallbackData):
    user = main_conn.execute("select name, text from all_user where id = (?);", (message.from_user.id,)).fetchall()
    if not user or user[0][0] == "user":
        if not user or user[0][1] is not None:
            main_conn.execute("insert into all_user(name,id,text) values ('user',?,'name');", (message.from_user.id,))
            await bot.send_message(message.from_user.id, "Ism familiyangizni kiriting")
        else:
            callback_query = {"page": '1'}
            await user_lessen(message, main_conn, vote_cb, callback_query)
    elif user and user[0][0] == "admin":
        await admin_menu(message, vote_cb, main_conn)


async def user_name(message: types.Message, main_conn: sqlite3.Connection):
    text = message.text
    main_conn.execute(f"""insert into students(id,name) values ({message.from_user.id},?)""", (text,))
    main_conn.execute("update all_user set text = 'age' where id = (?);", (message.from_user.id,))
    await bot.send_message(message.from_user.id, "Yoshingizni kiriting")


async def user_age(message: types.Message, main_conn: sqlite3.Connection):
    main_conn.execute("update students set age = (?) where id = (?);", (int(message.text), message.from_user.id))
    main_conn.execute("update all_user set text = 'contact' where id = (?);", (message.from_user.id,))
    markup = ReplyKeyboardMarkup(resize_keyboard=True).add(KeyboardButton("📱Telefon", request_contact=True))
    await bot.send_message(message.from_user.id, "Telefon raqamingizni yuboring", reply_markup=markup)


async def user_contact(message: types.Message, main_conn: sqlite3.Connection):
    number = message.contact.phone_number
    main_conn.execute("update students set phone_number = (?) where id = (?);",
                      (int(number[1:]), message.from_user.id))
    main_conn.execute("update all_user set text = 'reason' where id = (?);", (message.from_user.id,))
    await bot.send_message(message.from_user.id, "Nima maqsadda SMM o'rganmoqchisiz",
                           reply_markup=ReplyKeyboardRemove())


async def user_reason(message: types.Message, main_conn: sqlite3.Connection):
    text = message.text
    main_conn.execute(f'''update students set reason = (?) where id = (?);''',
                      (text, message.from_user.id,))
    main_conn.execute("update all_user set text = 'work' where id = (?);", (message.from_user.id,))
    await bot.send_message(message.from_user.id, "Hozirgi paytda ish yoki o'qish joyingiz?")


async def user_work(message: types.Message, main_conn: sqlite3.Connection,
                    vote_cb: aiogram.utils.callback_data.CallbackData):
    text = message.text
    main_conn.execute(f"""update students set work = (?) where id = (?);""",
                      (text, message.from_user.id,))
    main_conn.execute("update all_user set text = null where id = (?);", (message.from_user.id,))
    user = main_conn.execute("select name from students where id = (?);", (message.from_user.id,)).fetchall()[0][0]
    await bot.send_message(message.from_user.id,
                           f"Assalomu aleykum, xurmatli\n{user}!\n\nSiz \"SMM, MARKETING, SOTUV\" darsliklariga muvafaqiyatli ro'yxatdan o'tdingiz!")
    video = main_conn.execute("select video from lessen_table where id = 0;").fetchall()
    if video:
        markup = InlineKeyboardMarkup(row_width=3).add(
            InlineKeyboardButton(text="START", callback_data=vote_cb.new(rol='user', action="lessen", id="start", page='1'))
        )
        await bot.send_video(message.from_user.id, video[0][0], caption="SMM darsliklarni boshlash uchun \"START\" tugmasini bosing", reply_markup=markup)
