import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher

from admin.message import admin_message
from config import TOKEN
from user.lessen import user_opinion
from user.start import user_name, user_age, user_reason, user_work

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


async def user_message(message: types.Message, main_conn: sqlite3.Connection,
                       vote_cb: aiogram.utils.callback_data.CallbackData, user: list):
    text = user[1]
    if text == "name":
        await user_name(message, main_conn)
    elif text == "age":
        try:
            await user_age(message, main_conn)
        except:
            await bot.send_message(message.from_user.id, "Iltimos yoshingizni raqam ko'rinishida kiriting")
    elif text == "reason":
        await user_reason(message, main_conn)
    elif text == "work":
        await user_work(message, main_conn, vote_cb)
    elif text == "main fikr":
        await user_opinion(message, main_conn)
