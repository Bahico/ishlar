import sqlite3

import aiogram.utils.callback_data
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher

from config import TOKEN
from user.lessen import user_lessen, user_smile, user_finish, user_mes

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


async def user_callback(message: types.CallbackQuery, main_conn: sqlite3.Connection,
                        vote_cb: aiogram.utils.callback_data.CallbackData, callback_query: dict):
    if callback_query["action"] == "lessen":
        if callback_query["id"] == "start":
            await user_lessen(message, main_conn, vote_cb, callback_query)
    elif callback_query["action"] == "reaction":
        await user_smile(message, main_conn, vote_cb, callback_query)

    elif callback_query["action"] == "finish":
        await bot.delete_message(message.from_user.id, message.message.message_id)
        if callback_query["page"] == "I":
            await user_mes(message, main_conn)
        else:
            await user_finish(message, main_conn, callback_query)
