arr = ["salom"]
arr = arr[0:10]

print(arr)